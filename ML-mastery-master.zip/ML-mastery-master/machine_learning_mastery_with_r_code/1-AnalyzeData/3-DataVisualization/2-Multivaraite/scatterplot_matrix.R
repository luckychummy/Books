# Multivariate Scatterplot Matrix

# load the data
data(iris)
# pair-wise scatterplots of all 4 attributes
pairs(iris)
